class PostsController < ApplicationController
before_action :authenticate_user
def index
    user = User.find_by(login: session[:user_id])
    @role = Role.find_by(name: user.role)
    @post = Post.new
    @posts = Post.all
    

end


def authenticate_user
    unless User.find_by(login: session[:user_id]).present?
      redirect_to new_session_path
    end
  end
  


def show
    @post = Post.find_by(id: params[:id])

    @room_for_post = Room.find_by(admin: @post.autor)
end

def create
    user = User.find_by(login: session[:user_id])
    role = Role.find_by(name: user.role)
    if role.create_posts == true
        Post.create(data)
        redirect_to posts_path
    else 
        redirect_to user_path(user.login), notice: "Вы не можете создавать посты"
    end
    
end

def destroy
    Post.delete(params[:id])
    redirect_to posts_path
end


private 

def data 
    params.require(:post).permit(:header, :body, :autor)
end


end
