class SessionsController < ApplicationController
  def new
    @user = User.new
  end

  def create
    
    user = User.find_by(login: user_params[:login])

    if user && user.authenticate(user_params[:password])
      session[:user_id] = user.login
      redirect_to rooms_path, notice: "Вы успешно вошли в систему!"
    else
      redirect_to new_session_path, notice: "Не верный логин или пароль"
    end
  end


  private

  def user_params
    params.require(:user).permit(:login, :password)
  end
end
