class RoomsController < ApplicationController

    before_action :authenticate_user 
    before_action :authenticate_room, only:[:show]




    def index
      @rooms = Room.all
      @room = Room.new
      @user = User.find_by(login: session[:user_id])
      @user_role = Role.find_by(name: @user.role)
      @admin = Room.find_by(admin: session[:user_id])
      @myroom = Room.find_by(admin: session[:user_id])


    end



    def search
      nameRoom = params.require(:name)
      if (room = Room.find_by(name: nameRoom))
        redirect_to room_path(room.name) # используем name, т.к. это PK
      else
        redirect_to root_path, notice: "НЕ НАЙДЕНО!"
      end
    end
    



  def new
    @room = Room.new
  end

  def create
    user = User.find_by(login: session[:user_id])
    user_role = Role.find_by(name: user.role)
    if user_role.create_room = true
      @admin = Room.find_by(admin: session[:user_id])
      if @admin.nil?
        @room = Room.new(data_room)
        @room.admin = user.login # явно указываем админа комнаты
        if @room.save
          redirect_to room_path(@room.name), notice: 'Добро пожаловать в ВАШ чат! :)'
        else
          redirect_to rooms_path
        end
      else
        redirect_to root_path, notice: "Вы не можете создать чат"
      end
    else
      redirect_to user_path(user.login), notice: "Вам запрещено создавать чаты!"
    end
  end
  



  def destroy
    room = Room.find_by(name: params[:id])
    room.destroy
    redirect_to root_path
  end
  



  def show
    session[:name_room] = params[:id]
    session.delete(:name_room_to_connect)
    session.delete(:connect_room)
  

    @roomDate = Room.find_by(name: params[:id])
    @admin = User.find_by(login: session[:user_id])
  
    @adminOut = User.find_by(login: @roomDate.admin) if @roomDate
  
    @room = Room.new
    user = User.find_by(login: session[:user_id])
    @role = Role.find_by(name: user.role)
  
    @messages = Message.where(room: params[:id]) 
    @message = Message.new

    @ranks = RanksForUser.all
  end
  


  def authenticate_user
    unless User.find_by(login: session[:user_id]).present?
      redirect_to new_session_path
    end
  end
  





  def authenticate_room
    user = User.find_by(login: session[:user_id])
    room = Room.find_by(name: params[:id])
    role = Role.find_by(name: user.role)
    session[:name_room_to_connect] = room&.name
  
    if room.nil?
      redirect_to root_path, notice: "Комната не найдена"
      return
    end
  
    if room.password_digest.blank? || session[:connect_room] == true || room.name == session[:name_room]  || role.delete_content == true || role.edit_role == true || room.admin == user&.login
      
    else
      redirect_to room_authentications_path
    end
  end
  
  

  private
  def data_room
    params.require(:room).permit(:name, :description, :password)
  end
  
end
