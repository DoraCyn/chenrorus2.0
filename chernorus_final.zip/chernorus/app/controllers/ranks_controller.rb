class RanksController < ApplicationController
    def new
        @rank = Rank.new
        @rank_for_user = RanksForUser.new
        @ranks = Rank.all
        @users = User.all
    end

    def create
        rank = Rank.new(data_rank)
        rank.save

    end

    private

    def data_rank
        params.require(:rank).permit(:name, :body, :icon)
    end
end
    