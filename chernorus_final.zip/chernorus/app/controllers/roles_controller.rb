class RolesController < ApplicationController
    before_action :authenticate_admin


    def create

      role = Role.new(data_role)
      if role.save!
        redirect_to role_path
      end

    end
  
    def new
      @users = User.all
      @role = Role.new
      @roles = Role.all
    end
  
    def update
      user = User.find_by(login: session[:user_id])
      role = Role.find_by(name: user.role)

      if role.edit_role == true
        user_params = params.require(:user).permit(:login, :role)

        userUpdate = User.find_by(login: user_params[:login])
        userUpdate.update_column(:role, user_params[:role])

        redirect_to role_path
      else 
        redirect_to user_path(user.login), notice: "Вы не можете менять роли"

      

      end

    end
  
    private
  
    def data_role
      params.require(:role).permit(:name, :type_message, :delete_content, :edit_role, :create_room, :create_posts)
    end

    def authenticate_admin
      user = User.find_by(login: session[:user_id])
      role = Role.find_by(name: user.role)
      redirect_to root_path, alert: "У вас нет прав для выполнения этого действия." unless role.edit_role == true
    end
  end