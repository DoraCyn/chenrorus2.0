class RanksForUsersController < ApplicationController
        def create
            @rank_for_user = RanksForUser.new(rank_for_user_params)
            if @rank_for_user.save
                redirect_to new_rank_path, notice: "Звание назначено"
            else
                render :new
            end
        end

        private

        def rank_for_user_params
            params.require(:ranks_for_user).permit(:rank_name, :user_name)
        end

end
