class RoolesController < ApplicationController
    def index

    end
end
