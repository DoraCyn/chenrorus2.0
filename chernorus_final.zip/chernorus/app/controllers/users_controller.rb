require 'net/http'
require 'uri'
require 'json'

class UsersController < ApplicationController
  def new
    @user = User.new
  end

  def show
    url = URI('https://api.ipify.org?format=json')
    result = Net::HTTP.get(url)
    @ip = JSON.parse(result)

    @user = User.find_by(login: session[:user_id])
  end

  def create
    login = user_params[:login]

    if User.exists?(login: login)
      redirect_to new_user_path, alert: "Пользователь с таким логином уже существует"
    else
      @user = User.new(user_params)
      if @user.save
        redirect_to new_session_path, notice: "Пользователь успешно создан!"
      else
        if @user.login.length > 20
         return redirect_to new_user_path, notice: "ваш логин слишком большой"
        end

        if @user.nickname.length > 20
          return redirect_to new_user_path, notice: "ваш ник слишком большой"
        end

        if @user.worldview.length > 20
          return redirect_to new_user_path, notice: "ваше мировоззрение слишком большоe"
        end
        redirect_to new_user_path, notice: "Ошибка! Пользователь не создан"
      end
    end
  end

  def edit
    @user = User.find_by(login: session[:user_id]);
  end

  def update
    @user = User.find_by(login: session[:user_id]);
    @user.update(user_update);
    redirect_to user_path(@user), notice: "Ваш профиль обновлен"
  end

  private


  def user_update
    params.require(:user).permit(:password, :nickname, :worldview, :avatar)
  end

  def user_params
    params.require(:user).permit(:login, :password, :nickname, :worldview, :avatar)
  end
end
