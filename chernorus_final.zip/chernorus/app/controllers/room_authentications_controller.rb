class RoomAuthenticationsController < ApplicationController


    def show
        @room = Room.new
    end


    def create
        room_params = data()
        room = Room.find_by(name: room_params[:name]) # или другой атрибут для поиска комнаты
        
        if room && room.authenticate(room_params[:password])
          # Пароль верный
          
          session[:connect_room] = true
          redirect_to room_path(session[:name_room_to_connect])
        else
          # Пароль неверный
          redirect_to root_path
        end
    end
      
      def data
        params.require(:room).permit(:name, :password)
      end

end
