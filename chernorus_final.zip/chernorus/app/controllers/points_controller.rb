class PointsController < ApplicationController
    def index
        @points = Point.find_by(id: 1)
        @point = Point.new

    end

    def create
        @points = Point.find_by(id: 1)
        point = @points.points + 1

        @points.update(points: point)
        redirect_to points_path
    end


end
