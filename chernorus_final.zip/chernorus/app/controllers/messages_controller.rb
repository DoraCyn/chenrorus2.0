class MessagesController < ApplicationController
  def create
    user = User.find_by(login: session[:user_id])
    role = Role.find_by(name: user.role)
    room = Room.find_by(name: session[:name_room])

    if role&.type_message
      data = data_message
  
      if data[:text].blank?
        redirect_to room_path(room), notice: "Напишите сообщение"
        return
      end
  

  
      # Добавляем room и autor в параметры mass assignment
      message_params = data.merge(room: room, autor: user)
  
      @message = Message.new(message_params)
  
      if @message.save
        redirect_to room_path(room, anchor: 'bottom')
      else
        redirect_to room_path(room), alert: "Ошибка при сохранении сообщения"
      end
    else
      redirect_to user_path(user.login), notice: "Вам нельзя писать сообщения"
    end
  end
  



  def destroy
    @message = Message.find_by(id: params[:id])
    room = @message.room
  
    if @message.destroy
      redirect_to room_path(room), notice: "Сообщение удалено"
    else
      redirect_to room_path(room), alert: "Не удалось удалить сообщение"
    end
  end


  def data_message
    params.require(:message).permit(:text, :file)
  end
end