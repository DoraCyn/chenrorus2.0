module RanksHelper
end
