class RanksForUser < ApplicationRecord
    belongs_to :rank, foreign_key: :rank_name, primary_key: :id, optional: true
    
end