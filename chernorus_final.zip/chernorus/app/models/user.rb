class User < ApplicationRecord
  self.primary_key = :login
  has_secure_password
  validates :login, length: {minimum: 1, maximum: 20}, presence: true
  validates :password, presence: true
  validates :nickname, length: {minimum: 1, maximum: 20}, presence: true
  validates :worldview, length: {minimum: 1, maximum: 20}
  has_many :message
  has_one_attached :avatar
end
