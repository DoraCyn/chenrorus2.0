class Room < ApplicationRecord
  self.primary_key = :name
  has_secure_password validations: false
  has_many :messages, foreign_key: :room, primary_key: :name, dependent: :destroy
  validates :name, presence: true
end
