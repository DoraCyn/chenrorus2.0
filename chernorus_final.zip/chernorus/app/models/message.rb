class Message < ApplicationRecord
  belongs_to :room, foreign_key: :room, primary_key: :name
  belongs_to :autor, class_name: 'User', foreign_key: :autor, primary_key: :login
  has_one_attached :file
  validates :text, length:{minimum: 2, maximum: 300}, presence: true
end