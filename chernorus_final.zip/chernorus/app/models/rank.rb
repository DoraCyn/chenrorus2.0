class Rank < ApplicationRecord
    has_many :ranks_for_users, foreign_key: :rank_name, primary_key: :id
    
    has_one_attached :icon
end
