class Point < ApplicationRecord
end
