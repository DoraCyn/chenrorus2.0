class Post < ApplicationRecord
    validates :header,length:{minimum: 2, maximum: 60}, presence: true
    validates :body,length:{minimum: 0, maximum: 1000}, presence: true
end
