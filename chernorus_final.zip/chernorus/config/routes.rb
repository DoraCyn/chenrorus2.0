Rails.application.routes.draw do
  resources :points
  resources :klikers
  resources :posts
  resources :ranks
  resources :ranks_for_users




  root "rooms#index"
  
  resources :rooms

  resources :messages do
    collection do
      get 'update_messages'
    end
  end
  
  


  post 'search', to: 'rooms#search', as: 'rooms_search' 

  resource :room_authentications 

  resources :users

  

  resource :session

  resource :role

  resource :points


  get 'rooles', to: 'rooles#index', as: 'rooles'

  mount ActionCable.server => '/cable'





  
  # Render dynamic PWA files from app/views/pwa/*


end
