class CreatePosts < ActiveRecord::Migration[7.2]
  def change
    create_table :posts do |t|
      t.timestamps
      t.string :header
      t.text :body
      t.string :autor
    end
    add_foreign_key :posts, :users, column: :autor, primary_key: :login 
  end
end
