class CreateMessages < ActiveRecord::Migration[7.2]
  def change
    create_table :messages do |t|
      t.timestamps
      t.string :text, null: false
      t.string :autor, null: false
      t.string :room, null: false
    end
    add_foreign_key :messages, :users, column: :autor, primary_key: :login
    add_foreign_key :messages, :rooms, column: :room, primary_key: :name
  end
end
