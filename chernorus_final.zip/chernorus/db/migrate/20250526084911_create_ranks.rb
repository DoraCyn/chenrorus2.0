class CreateRanks < ActiveRecord::Migration[7.2]
  def change
    create_table :ranks do |t|
      t.string :name
      t.string :body
    end
  end
end
