class CreateRoles < ActiveRecord::Migration[7.2]
  def change
    create_table :roles, id: false, primary_key: :name do |t|
      t.timestamps
      t.string :name, null: false, primary_key: true
      t.boolean :type_message, default: true
      t.boolean :delete_content, default: false
      t.boolean :edit_role, default: false
      t.boolean :create_posts, default: true
      t.boolean :create_room, default: true
    end
  end
end
