class CreateRooms < ActiveRecord::Migration[7.2]
  def change
    create_table :rooms, id: false, primary_key: :name do |t|
      t.timestamps
      t.string :name, null: false, primary_key: true
      t.text :description
      t.string :password_digest
      t.string :admin, null: false
    end
    add_foreign_key :rooms, :users, column: :admin, primary_key: :login
  end
end
