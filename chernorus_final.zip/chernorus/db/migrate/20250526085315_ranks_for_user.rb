class RanksForUser < ActiveRecord::Migration[7.2]
  def change
    create_table :ranks_for_users do |t|
      t.string :user_name
      t.integer :rank_name
    end
    add_foreign_key :ranks_for_users, :users, column: :user_name, primary_key: :login
    add_foreign_key :ranks_for_users, :ranks, column: :rank_name, primary_key: :id
  end
end
