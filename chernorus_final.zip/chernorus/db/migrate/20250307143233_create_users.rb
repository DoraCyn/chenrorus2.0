class CreateUsers < ActiveRecord::Migration[7.2]
  def change
    create_table :users, id: false, primary_key: :login do |t|
      t.timestamps
      t.string :login, null: false, primary_key: true
      t.string :password_digest
      t.string :nickname
      t.string :worldview
      t.string :role, default: "user"
    end
    add_foreign_key :users, :roles, column: :role, primary_key: :name
  end
end


