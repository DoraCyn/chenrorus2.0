# # Создаём 10 пользователей
# 10.times do 
#     login = Faker::Name.name
#     nickname = Faker::Name.name
#     passwordUser = Faker::Internet.password(min_length: 8)  # Более надёжный пароль
#     User.create!(
#       login: login, 
#       nickname: nickname, 
#       password: passwordUser
#     )
#   end
  
#   # Создаём 10 комнат, привязывая к случайным пользователям
#   10.times do
#     nameRoom = Faker::Name.name
#     description = Faker::Quote.mitch_hedberg
#     password = Faker::Internet.password(min_length: 6)  # Пароль для комнаты
#     random_user = User.order("RANDOM()").first  # Берём случайного пользователя
    
#     Room.create!(
#       name: nameRoom,
#       description: description,
#       password: password,
#       user_id: random_user.id  # Привязываем к существующему пользователю
#     )
#   end




1000.times do

    text = Faker::Quote.mitch_hedberg
    roomid = rand(2..40)
    userid = rand(1..16)
    Message.create text: text, room_id: roomid, user_id: userid
end