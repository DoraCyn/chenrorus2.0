require "test_helper"

class AdminForRoomTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
