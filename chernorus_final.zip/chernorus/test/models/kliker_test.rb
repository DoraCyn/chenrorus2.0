require "test_helper"

class KlikerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
